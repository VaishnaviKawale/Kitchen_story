export class Admin {
    username: any
    password: any
}